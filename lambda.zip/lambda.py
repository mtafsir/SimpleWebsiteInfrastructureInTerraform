import json
import boto3


def lambda_handler(event, context):
    s3 = boto3.client('s3')
    bucket = 'mtafsir'
    resp = s3.list_objects(Bucket=bucket, MaxKeys=10)
    print("s3.list_objects returns", resp)